import os
# import time
import numpy as np

# start = time.time()

# directory = "./pressure_data"
# os.chdir("../../")
# directory = "./data"
# save_directory = "./output"

directory = "/data"
save_directory = "/output"

demand_src = "demand.csv"
apply_src = "site_bandwidth.csv"
qos_src = "qos.csv"
config_src = "config.ini"

save_file = "solution.txt"
if not os.path.exists(save_directory):
    os.makedirs(save_directory)

def read_csv(path):
    self_ele, self_data = [], {}
    with open(path, "r", encoding='UTF-8') as f:
        reader = f.readlines()
        for i, row in enumerate(reader):
            row_ = row.strip("\n").split(",")
            if i == 0:
                self_ele = row_[1:]
            else:
                self_data.update({row_[0]: row_[1:]})
    return self_data, self_ele

def read_config(path):
    with open(path, "r") as f:
        res = f.readlines()[-1]
        return res.split('=')[-1]

demand, demand_user_id = read_csv(os.path.join(directory, demand_src))
apply, _  = read_csv(os.path.join(directory, apply_src))
qos, qos_user_id = read_csv(os.path.join(directory, qos_src))
qos_constraint = int(read_config(os.path.join(directory, config_src)))

demand_keys = np.array([item for item in demand.keys()], dtype=np.str)
demand = np.array([list(item) for item in demand.values()], dtype=np.int)
qos_keys = np.array([item for item in qos.keys()], dtype=np.str)
qos = np.array([list(item) for item in qos.values()], dtype=np.int)

demand_sequence = np.argsort([sum(d) for d in demand])[::-1]

# 输出到最终output
def output(final_res):
    with open(os.path.join(save_directory, save_file), "w+") as f:
        for single_time_res in final_res:
            for single_user_name, single_user_value in zip(single_time_res.keys(), single_time_res.values()):
                f.write(f"{demand_user_id[single_user_name]}:")
                flag = 0
                for i, every_node_res in enumerate(single_user_value):
                    for every_node_name, every_node_value in zip(every_node_res.keys(), every_node_res.values()):
                        # print(every_node_name, every_node_value)
                        # 如果分配量为0,无需写入
                        if every_node_value == 0:
                            continue
                        else:
                            # 第一个分配前无需","
                            if not flag:
                                flag = 1
                            else:
                                f.write(",")
                            f.write(f"<{every_node_name},{every_node_value}>")
                f.write("\n")

# 计算有效用户节点
def find_useful_server():
    # 挑选出满足每个客户带宽需求的边缘节点
    def limit_server_qos(axis_input):
        index_temp = np.where(qos[:, axis_input] < qos_constraint)
        qos_temp = np.array((index_temp[0], qos[index_temp][:, axis_input])).T
        qos_temp = qos_temp[np.argsort(qos_temp[:, 1], axis=0)]
        return qos_temp

    # 每个用户满足的节点列表
    # 每个用户满足的节点数量排序
    client_limit_res, client_limit_sequence = [], []
    for i in range(len(demand[0])):
        client_limit_res.append(limit_server_qos(i))
        client_limit_sequence.append(len(limit_server_qos(i)))

    # 每个客户所有满足的边缘节点的列表
    # 增加排序，（由于边缘节点时延目前无需考虑，直接按照序号排列），保证满足边缘节点搜索优先度
    _server_list = [sorted(list(client_limit_res[i][:, 0])) for i in range(len(client_limit_sequence))]
    # 每个客户拥有满足的边缘节点的数量
    # 根据满足边缘节点进行排序，按照每个客户节点可以满足个数升序排序
    _server_num_sequence = np.argsort(np.array(client_limit_sequence))
    # 排除完全没有边缘可以满足的用户
    while not len(_server_list[_server_num_sequence[0]]):
        _server_num_sequence = np.delete(_server_num_sequence, 0)
    # 所有可用边缘节点集合
    _server_set = []
    # 构建所有可用边缘节点列表
    for x in client_limit_res:
        _server_set += list(x[:, 0])
    _server_set = set(_server_set)

    return _server_list, _server_num_sequence, _server_set

# 边缘节点列表, 边缘节点数量队列, 边缘节点集合
server_list, server_num_sequence, server_set = find_useful_server()
# 前百分之5请求分界线(95%总请求次数向上取整)
demand_limit = len(demand) - np.ceil(len(demand) * 0.95)
# 最终结果
final_res = []
# 节点使用量统计
server_total_use_bandwidth = {qos_keys[ii]: [] for ii in server_set}
# 节点使用次数统计
server_total_use_num = {s:0 for s in server_set}
# 总计已经使用边缘节点集合
server_pool_avg = []
# 等待分配边缘节点池(按平均分配策略)
server_wait_pool_avg = {i:[] for i in range(len(list(server_num_sequence)))}
# 等待分配边缘节点池(按最大分配策略)
server_wait_pool_max = server_list
# server_wait_pool_max = [[*sub_list] for sub_list in server_list]   # 全局复制自server_list
# 开始进行匹配
for num, demand_index in enumerate(demand_sequence):
    # 从时间序列上按用户需求总量降序匹配
    query_bandwidth = demand[demand_index]
    # 等待分配用户节点池
    client_wait_pool = list(server_num_sequence)
    # 单次分配结果字典
    single_res = {i:[] for i in range(len(client_wait_pool))}
    # 已经使用边缘节点池
    server_used_pool = {i:[] for i in range(len(client_wait_pool))}
    # 此时已经使用边缘节点集合
    already_use_set = []
    # 全局边缘节点带宽大小
    server_bandwidth = {node: int(apply[qos_keys[node]][0]) for node in server_set}

    while len(client_wait_pool):
        user = client_wait_pool[0]
        # 处理入口
        def handler(query):
            # 如果最大策略等待分配边缘节点池还有可用节点
            if len(server_wait_pool_max[user]):
                max_strategy(query)
            else:
                mean_strategy(query)


        # 最大策略
        def max_strategy(query):
            # 弹出当前用户边缘节点池顶端节点作为第一首选分配
            # use_node_index: 使用边缘节点索引
            use_node_index = server_wait_pool_max[user].pop(0)
            # use_node_name: 使用边缘节点名称
            use_node_name = qos_keys[use_node_index]
            # use_node_bandwidth: 使用边缘节点带宽
            use_node_bandwidth = server_bandwidth[use_node_index]
            # 加入已使用边缘节点池
            server_used_pool[user].append(use_node_index)
            # 如果请求 > 提供，单个边缘不能满足分配
            if query > use_node_bandwidth:
                # 如果还有用户也有这个边缘节点，删除，保证不再进行分配
                for x in client_wait_pool:
                    if use_node_index in server_wait_pool_max[x]:
                        server_wait_pool_max[x].remove(use_node_index)
                        # 加入已使用边缘节点池
                        server_used_pool[x].append(use_node_index)
                # 存储单个分配节点信息
                single_res[user].append({use_node_name: use_node_bandwidth})
                server_bandwidth[use_node_index] = 0
                # 递归边缘节点池,寻找下一个可用边缘节点
                handler(query - use_node_bandwidth)
            # 如果请求 < 提供，能满足
            else:
                # 存储当前用户分配节点信息
                single_res[user].append({use_node_name: query})
                server_bandwidth[use_node_index] -= query
                # 该用户需求已分配完, 退出等待分配池
                client_wait_pool.pop(0)
                # 下面开始尝试分配该边缘节点剩余带宽给其它用户
                # 当前边缘节点剩余可分配带宽
                free = use_node_bandwidth - query
                # 遍历剩下的用户节点
                for x in client_wait_pool.copy():
                    # 如果还有用户也有这个边缘节点，给它分配
                    if use_node_index in server_wait_pool_max[x]:
                        # 保证该用户不再请求这个节点
                        server_wait_pool_max[x].remove(use_node_index)
                        # 加入已使用边缘节点池
                        server_used_pool[x].append(use_node_index)
                        # 需求带宽大小
                        query = query_bandwidth[x]
                        # 如果已经没有可分配带宽,则直接从该用户边缘节点池删除然后找下一个用户
                        if free == 0:
                            continue
                        # 如果分配不能完全，提供可提供部分
                        elif query >= free:
                            # 存储单个分配节点信息
                            single_res[x].append({use_node_name: free})
                            server_bandwidth[use_node_index] = 0
                            # 更新分配数量
                            query_bandwidth[x] -= free
                            free = 0
                        # 如果分配能够完全，分配该用户然后从等待列表里退出
                        else:
                            # 存储单个分配节点信息
                            single_res[x].append({use_node_name: query})
                            server_bandwidth[use_node_index] -= query
                            # 更新分配数量
                            free -= query_bandwidth[x]
                            query_bandwidth[x] = 0
                            # 该用户需求已分配完, 退出等待分配池
                            client_wait_pool.remove(x)


        def mean_strategy(query):
            # 当前用户使用均值分配的边缘节点列表
            use_node_index_list = server_wait_pool_avg[user].copy()

            # 迭代满足需求
            while query != 0:
                # 计算均值策略可用各边缘节点使用率
                use_rate = {node: (int(apply[qos_keys[node]][0]) - server_bandwidth[node]) / int(apply[qos_keys[node]][0])
                            for node in use_node_index_list}
                # 按照最大使用率差值计算各节点富余分配量
                deliver_dict = {node: int((max(use_rate.values()) - use_rate[node]) * int(apply[qos_keys[node]][0]))
                                for node in use_node_index_list}

                # print(use_rate)
                # print(deliver_dict)
                if query >= sum(deliver_dict.values()):
                    res_query = query - sum(deliver_dict.values())
                    # 平均分担当前待分配带宽
                    mean_deliver = res_query // len(use_node_index_list)
                    left_deliver = res_query % len(use_node_index_list)
                    for node in use_node_index_list:
                        deliver_dict[node] += mean_deliver
                else:
                    temp = sum(deliver_dict.values())
                    for node in use_node_index_list:
                        deliver_dict[node] = int(query * (deliver_dict[node] / temp))
                    left_deliver = query - sum(deliver_dict.values())
                # print(deliver_dict)
                # print(sum(deliver_dict.values()), query-sum(deliver_dict.values())-left_deliver)

                for use_node_index in use_node_index_list.copy():
                    use_node_name = qos_keys[use_node_index]
                    free = server_bandwidth[use_node_index]
                    if left_deliver > 0:
                        need = deliver_dict[use_node_index] + left_deliver
                        left_deliver = 0
                    else:
                        need = deliver_dict[use_node_index]
                    # # 如果待分配带宽为0
                    # if free == 0:
                    #     continue
                    # 如果分配请求超过该节点可提供带宽上限
                    if need > free:
                        # 存储单个分配节点信息
                        single_res[user].append({use_node_name: free})
                        # 请求总量减小
                        query -= free
                        # 均值策略该节点待分配量归0
                        server_bandwidth[use_node_index] = 0
                        use_node_index_list.remove(use_node_index)
                    else:
                        # 分配量为均值
                        single_res[user].append({use_node_name: need})
                        # 请求总量减小
                        query -= need
                        # 均值策略该节点待分配量减小
                        server_bandwidth[use_node_index] -= need
            # 该用户需求已分配完, 退出等待分配池
            client_wait_pool.pop(0)

        handler(query_bandwidth[user])

    # 对使用过的节点数量计数
    for value in server_used_pool.values():
        already_use_set = list(set(already_use_set + value))
    for index in already_use_set:
        server_total_use_num[index] += 1

    # 动态调整边缘节点池
    for key, value in zip(server_used_pool.keys(), server_used_pool.values()):
        for index in sorted(value):
            # 如果某个节点不超过5%临界点, 循环到极值策略待分配节点池最后
            if server_total_use_num[index] < demand_limit:
                server_wait_pool_max[key].append(index)
            # 否则丢入均值策略待分配节点池
            elif index not in server_wait_pool_avg[key]:
                server_wait_pool_avg[key].append(index)
        server_pool_avg += server_wait_pool_avg[key]
    # 目前已经存在于均值策略边缘节点池的节点
    server_pool_avg = list(set(server_pool_avg))


    # def Calc_points():
    #     temp_res = {qos_keys[ii]: 0 for ii in server_set}
    #     for key, value in zip(single_res.keys(), single_res.values()):
    #         for res in value:
    #             for name, num in zip(res.keys(), res.values()):
    #                 temp_res[name] += num
    #     for name, num in zip(temp_res.keys(), temp_res.values()):
    #         server_total_use_bandwidth[name].append(num)
    #     for name in server_total_use_bandwidth.keys():
    #         server_total_use_bandwidth[name] = sorted(server_total_use_bandwidth[name], reverse=True) if len(server_total_use_bandwidth[name]) else []
    # Calc_points()

    final_res.append(single_res)
    # print(server_pool_avg)
    # print(server_wait_pool_avg)

# 按照原先顺序调整
temp = final_res.copy()
for i, index in enumerate(demand_sequence):
    final_res[index] = temp[i]

output(final_res)

# end = time.time()
# print(end - start)
