import os
# import time
import numpy as np

# start = time.time()

# os.chdir("../../")
# directory = "./pressure_data"
# directory = "./data"
# save_directory = "./output"

directory = "/data"
save_directory = "/output"

demand_src = "demand.csv"
apply_src = "site_bandwidth.csv"
qos_src = "qos.csv"
config_src = "config.ini"

save_file = "solution.txt"
if not os.path.exists(save_directory):
    os.makedirs(save_directory)

def read_csv(path):
    self_ele, self_data = [], {}
    with open(path, "r", encoding='UTF-8') as f:
        reader = f.readlines()
        for i, row in enumerate(reader):
            row_ = row.strip("\n").split(",")
            if i == 0:
                self_ele = row_[1:]
            else:
                self_data.update({row_[0]: row_[1:]})
    return self_data, self_ele

def read_config(path):
    with open(path, "r") as f:
        res = f.readlines()[-1]
        return res.split('=')[-1]

demand, demand_user_id = read_csv(os.path.join(directory, demand_src))
apply, _  = read_csv(os.path.join(directory, apply_src))
qos, qos_user_id = read_csv(os.path.join(directory, qos_src))
qos_constraint = int(read_config(os.path.join(directory, config_src)))

demand2 = np.array([list(item) for item in demand.values()], dtype=np.int)
demand2_keys = np.array([item for item in demand.keys()], dtype=np.str)
qos2 = np.array([list(item) for item in qos.values()], dtype=np.int)
qos2_keys = np.array([item for item in qos.keys()], dtype=np.str)
# apply2 = np.array([item for item in apply.values()], dtype=np.int)
# apply2_keys = np.array([item for item in apply.keys()], dtype=np.str)

# 挑选出满足每个客户带宽需求的边缘节点
def limit_bandwidth(axis_input):
    index_temp = np.where(qos2[:, axis_input] < qos_constraint)
    qos_temp = np.array((index_temp[0], qos2[index_temp][:, axis_input])).T
    qos_temp = qos_temp[np.argsort(qos_temp[:, 1], axis=0)]
    return qos_temp

qos_limit_res = []
qos_limit_rank = []
for i in range(len(demand2[0])):
    qos_limit_res.append(limit_bandwidth(i))
    qos_limit_rank.append(len(limit_bandwidth(i)))
# 每个客户所有满足的边缘节点的列表
# 增加排序，（由于边缘节点时延目前无需考虑，直接按照序号排列），保证满足边缘节点搜索优先度
qos_all_enable = []
for i in range(len(qos_limit_rank)):
    qos_all_enable.append(sorted(list(qos_limit_res[i][:, 0])))
# 根据满足边缘节点进行排序，按照每个客户节点可以满足个数升序排序
query_rank = np.argsort(np.array(qos_limit_rank))

while not len(qos_all_enable[query_rank[0]]):
    query_rank = np.delete(query_rank, 0)


def output(final_res):
    with open(os.path.join(save_directory, save_file), "w+") as f:
        for single_time_res in final_res:
            for single_user_name, single_user_value in zip(single_time_res.keys(), single_time_res.values()):
                f.write(f"{demand_user_id[single_user_name]}:")
                flag = 0
                for i, every_node_res in enumerate(single_user_value):
                    for every_node_name, every_node_value in zip(every_node_res.keys(), every_node_res.values()):
                        print(every_node_name, every_node_value)
                        if every_node_value == 0:
                            continue
                        else:
                            if not flag:
                                flag = 1
                            else:
                                f.write(",")
                            f.write(f"<{every_node_name},{every_node_value}>")
                # f.write(os.linesep)
                f.write("\n")


final_res = []
# 开始进行匹配
for query_bandwidth in demand2:
    single_time_use_node_set, use_node_details = [], {i:[] for i in range(len(qos_all_enable))}
    user_wait_index = list(query_rank)
    apply_wait_index = [[*sub_list] for sub_list in qos_all_enable]   # 全局复制
    while len(user_wait_index):
        user = user_wait_index[0]
        def handler(query):
            # 弹出用户可分配队列顶端节点作为第一首选分配
            use_node_index = apply_wait_index[user].pop(0)
            use_node_name = qos2_keys[use_node_index]
            # 如果请求 > 提供，不能满足
            if query > int(apply[use_node_name][0]):
                # # 如果满足条件的边缘点全部分配完了，直接结束
                # if not len(apply_wait_index[user]):
                #     # 该用户分配完成
                #     user_wait_index.pop(0)
                #     for j in user_wait_index:
                #         if use_node_index in apply_wait_index[j]:
                #             apply_wait_index[j].remove(use_node_index)
                #     return
                for x in user_wait_index:
                    # 如果还有用户也有这个边缘节点，给它分配
                    if use_node_index in apply_wait_index[x]:
                        # 所有拥有该节点的用户不再请求该节点
                        apply_wait_index[x].remove(use_node_index)
                # 存储单个分配节点信息
                use_node_details[user].append({use_node_name: int(apply[use_node_name][0])})
                handler(query - int(apply[use_node_name][0]))
            # 如果请求 < 提供，能满足
            else:
                # 该用户分配完成
                user_wait_index.pop(0)
                # 存储单个分配节点信息
                use_node_details[user].append({use_node_name: query})
                # 当前边缘节点剩余可分配带宽
                free = int(apply[use_node_name][0]) - query
                user_temp = user_wait_index.copy()
                # 遍历剩下的用户节点
                for x in user_temp:
                    # 如果还有用户也有这个边缘节点，给它分配
                    if use_node_index in apply_wait_index[x]:
                        # 所有拥有该节点的用户不再请求该节点
                        apply_wait_index[x].remove(use_node_index)
                        # 需求带宽大小
                        need = query_bandwidth[x]
                        if free == 0:
                            continue
                        # 如果分配不能完全，提供可提供部分
                        elif need >= free:
                            # 存储单个分配节点信息
                            use_node_details[x].append({use_node_name: free})
                            # 更新分配数量
                            query_bandwidth[x] -= free
                            free = 0
                        # 如果分配能够完全，分配该用户然后从等待列表里退出
                        else:
                            # 存储单个分配节点信息
                            use_node_details[x].append({use_node_name: need})
                            # 更新分配数量
                            free -= query_bandwidth[x]
                            query_bandwidth[x] = 0
                            # print(use_node_details)
                            # 等待队列删除该用户
                            user_wait_index.remove(x)
                    # # 如果取出的边缘节点已经在本轮被其它客户节点分配
                    # if len(set(single_time_use_node_set + use_node)) != num + 1:
                    #     # 当前使用边缘节点列表里退出该节点，并重新检索
                    #     use_node.pop()
                    #     return gloabl_deliver_check()
                    # else:
                    #     # 返回当前分配节点名称
                    #     name = qos2_keys[use_node_index]
                    #     return name
        handler(query_bandwidth[user])
        # single_time_use_node_set += use_node
        # # 存储单个时间序列最终的输出结果
        # single_time_use_node_details.append({i: use_node_details})
    final_res.append(use_node_details)
    # print(use_node_details)

output(final_res)

# end = time.time()
# print(end - start)
