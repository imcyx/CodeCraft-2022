# -*- coding: utf-8 -*-
# @Time    : 2022/3/23 15:51
# @Author  : CYX
# @Email   : im.cyx@foxmail.com
# @File    : Code_test.py
# @Software: PyCharm
# @Project : CodeCraft-2022

import os
# import time
import numpy as np

# start = time.time()

# os.chdir("../../")
# directory = "./data"
# save_directory = "./output"

directory = "/data"
save_directory = "/output"

demand_src = "demand.csv"
apply_src = "site_bandwidth.csv"
qos_src = "qos.csv"
config_src = "config.ini"

save_file = "solution.txt"
if not os.path.exists(save_directory):
    os.makedirs(save_directory)


def read_csv(path):
    self_ele, self_data = [], {}
    with open(path, "r", encoding='UTF-8') as f:
        reader = f.readlines()
        for i, row in enumerate(reader):
            row_ = row.strip("\n").split(",")
            if i == 0:
                self_ele = row_[1:]
            else:
                self_data.update({row_[0]: row_[1:]})
    return self_data, self_ele


def read_config(path):
    with open(path, "r") as f:
        res = f.readlines()[-1]
        return res.split('=')[-1]


demand, demand_user_id = read_csv(os.path.join(directory, demand_src))
apply, _ = read_csv(os.path.join(directory, apply_src))
qos, qos_user_id = read_csv(os.path.join(directory, qos_src))
qos_constraint = int(read_config(os.path.join(directory, config_src)))

demand_keys = np.array([item for item in demand.keys()], dtype=np.str)
demand = np.array([list(item) for item in demand.values()], dtype=np.int)
qos_keys = np.array([item for item in qos.keys()], dtype=np.str)
qos = np.array([list(item) for item in qos.values()], dtype=np.int)

demand_sequence = np.argsort([sum(d) for d in demand])[::-1]


# 输出到最终output
def output(final_res):
    with open(os.path.join(save_directory, save_file), "w+") as f:
        for single_time_res in final_res:
            for single_user_name, single_user_value in zip(single_time_res.keys(), single_time_res.values()):
                f.write(f"{demand_user_id[single_user_name]}:")
                flag = 0
                for i, every_node_res in enumerate(single_user_value):
                    for every_node_index, every_node_value in zip(every_node_res.keys(), every_node_res.values()):
                        # print(every_node_index, every_node_value)
                        # 如果分配量为0,无需写入
                        if every_node_value == 0:
                            continue
                        else:
                            # 第一个分配前无需","
                            if not flag:
                                flag = 1
                            else:
                                f.write(",")
                            f.write(f"<{qos_keys[every_node_index]},{every_node_value}>")
                f.write("\n")


# 计算有效用户节点
def find_useful_server():
    # 挑选出满足每个客户带宽需求的边缘节点
    def limit_server_qos(axis_input):
        index_temp = np.where(qos[:, axis_input] < qos_constraint)
        qos_temp = np.array((index_temp[0], qos[index_temp][:, axis_input])).T
        qos_temp = qos_temp[np.argsort(qos_temp[:, 1], axis=0)]
        return qos_temp

    # 每个用户满足的节点列表
    # 每个用户满足的节点数量排序
    _client_limit_res, _client_limit_num_sequence, _client_limit_band_sequence = [], [], []
    for i in range(len(demand[0])):
        _server_res = limit_server_qos(i)
        _client_limit_res.append(_server_res)
        _client_limit_num_sequence.append(len(_server_res))
        _client_limit_band_sequence.append(sum([int(apply[qos_keys[x]][0]) for x in _server_res[:, 0]]))

    # 所有可用边缘节点集合
    _server_all = []
    # 构建所有可用边缘节点列表
    for x in _client_limit_res:
        _server_all += list(x[:, 0])
    _server_set = set(_server_all)

    # 每个客户所有满足的边缘节点的列表
    # 增加排序，（由于边缘节点时延目前无需考虑，直接按照序号排列），保证满足边缘节点搜索优先度
    _server_list = [sorted(list(_client_limit_res[i][:, 0])) for i in range(len(_client_limit_num_sequence))]

    # _server_dict = {i: 0 for i in _server_set}
    # for j in _server_all:
    #     _server_dict[j] += 1
    # for i, node in enumerate(_server_list):
    #     data = np.array([[s, _server_dict[s]] for s in node])
    #     # data = data[data[:, 1].argsort()][:, 0]
    #     data = data[data[:, 1].argsort()[::-1]][:, 0]
    #     _server_list[i] = data.tolist()
    # print(_server_dict)

    # _server_freq = {s: 0 for s in _server_set}
    # for ss in _server_list:
    #     for j in ss:
    #         _server_freq[j]+=1
    # _server_freq = sorted(_server_freq.items(), key=lambda d: d[1], reverse=True)
    # _server_freq = [i[0] for i in _server_freq]

    # 每个客户拥有的满足边缘节点升序排序,首要排序指标数量,次要排序指标可提供带宽
    _server_num_sequence = np.argsort(np.array((_client_limit_num_sequence, _client_limit_band_sequence)).T, axis=0)
    # _server_num_sequence = [j[0] if j[0]==j[1] else j[1] for j in _server_num_sequence]
    _server_num_sequence = [j[0] for j in _server_num_sequence]
    # 排除完全没有边缘可以满足的用户
    while not len(_server_list[_server_num_sequence[0]]):
        _server_num_sequence = np.delete(_server_num_sequence, 0)

    # 对客户表进行排序
    temp_dict = {j: i for i, j in enumerate(_server_num_sequence)}
    _client_list = {j: [] for j in _server_set}
    for client, s_list in enumerate(_server_list):
        for s in s_list:
            _client_list[s].append(client)
    for k, cc in zip(_client_list.keys(), _client_list.values()):
        x = np.array([[c, temp_dict[c]] for c in cc])
        x = x[np.argsort(x[:, 1])][:, 0]
        _client_list[k] = x.tolist()

    temp = []
    _client_num_sequence = []
    for y in _client_list.values():
        temp.append(len(y))
    temp_list = list(_server_set)
    for i, j in enumerate(np.argsort(temp)):
        _client_num_sequence.append(temp_list[j])
    _server_set = _client_num_sequence

    return _server_list, _server_num_sequence, _server_set, _client_list


# 边缘节点列表, 边缘节点数量队列, 边缘节点集合
server_list, server_num_sequence, server_set, client_wait_pool_max = find_useful_server()

demand_avg = np.sum(demand,axis=0)/len(demand)
demand_avg = [int(avg // len(server_list[i])) for i, avg in enumerate(list(demand_avg))]
server_avg_list = {i: 0 for i in server_set}
res_free = {}
# 循环检索边缘拥有用户列表
for server, client_list in zip(client_wait_pool_max.keys(), client_wait_pool_max.values()):
    # 计算当前用户手头用户列表各用户均分值之和 与 边缘节点上限 差值
    free = sum(demand_avg[client] for client in client_list) - int(apply[qos_keys[server]][0])
    # 如果超过节点上限
    if free > 0:
        # 期待均值最大值为上限
        server_avg_list[server] = int(apply[qos_keys[server]][0])
        # # 将多出来的值分摊各用户,并记住
        # for client in client_list:
        #     if client in res_free.keys():
        #         res_free[client] += free // len(client_list)
        #     else:
        #         res_free.update({client: free // len(client_list)})
        #     # demand_avg[client] += free // len(client_list)
    # 否则加到各节点
    else:
        # 分配各边缘加到均值和
        for client in client_list:
            server_avg_list[server] += demand_avg[client]
        # for client in client_list:
        #     if client in res_free.keys():
        #         if res_free[client] < free:
        #             server_avg_list[server] += demand_avg[client]


    # for client in client_list:
    #     server_avg_list[server] += demand_avg[client]
# for i, server_list in enumerate(server_list):
#     deliver_total = demand_avg[i]
#     server_temp = server_list.copy()
#     # for server in server_set:
#
#
#
#     # 分配量不能超过该节点上限
#     while deliver_total > 0:
#         # 先平均分配
#         deliver = deliver_total / len(server_temp)
#         for s in server_temp:
#             # 当前该节点可分配数量
#             free = int(apply[qos_keys[s]][0]) - server_avg_list[s]
#             # 如果当前考虑的边缘节点已经被分配超过上限
#             if deliver > free:
#                 # 分配到顶
#                 server_avg_list[s] = int(apply[qos_keys[s]][0])
#                 # 去除已经分配的量
#                 deliver_total -= free
#                 # 移除该节点
#                 server_temp.remove(s)
#             # 否则, 不超过分配上限的话, 按需分配
#             else:
#                 # 按计算值分配
#                 server_avg_list[s] += int(deliver)
#                 deliver_total -= deliver
#
#     print(deliver_total)


# 前百分之5请求分界线(95%总请求次数向上取整)
demand_limit = len(demand) - np.ceil(len(demand) * 0.95)
# 最终结果
final_res = []
# 各边缘使用量统计（超过临界点后不计）
server_total_use_bandwidth = {ii: [] for ii in server_set}
# 节点使用次数统计
server_total_use_num = {s: 0 for s in server_set}
# 等待分配边缘节点池(按平均分配策略)
server_max_avg = {i: 0 for i in server_set}
# 等待分配边缘节点池(按最大分配策略)
server_wait_pool_max = server_set.copy()

# 开始进行匹配
for num, demand_index in enumerate(demand_sequence):
    # 从时间序列上按用户需求总量降序匹配
    client_query_bandwidth = demand[demand_index]
    # 等待分配用户节点池
    client_wait_pool = list(server_num_sequence)
    # 等待分配边缘节点池
    server_wait_pool = server_wait_pool_max.copy()
    # 单次分配结果字典
    single_res = {i: [] for i in range(len(client_wait_pool))}
    # 全局边缘节点带宽大小
    server_bandwidth = {node: int(apply[qos_keys[node]][0]) for node in server_set}

    # 持续搜索边缘等待池子
    for server_index in server_wait_pool:
        # 当前边缘需要分配带宽
        server_now_bandwidth = server_bandwidth[server_index]

        user_list_temp = {}
        # 从边缘角度递归每个边缘的用户
        for user in client_wait_pool_max[server_index]:
            # 如果用户还在用户池子里
            if user in client_wait_pool:
                # use_server_bandwidth: 用户剩余请求带宽
                query = client_query_bandwidth[user]
                # 如果这个用户的需求超过了当前服务器闲置带宽
                if query >= server_now_bandwidth:
                    # 分配所有闲置带宽
                    single_res[user].append({server_index: server_now_bandwidth})
                    # 如果user_list_temp有东西，说明不是一个节点填满的，写进去
                    for u, q in zip(user_list_temp.keys(), user_list_temp.values()):
                        # 保存分配
                        single_res[u].append({server_index: q})
                        # 用户请求量更新
                        client_query_bandwidth[u] = 0
                        # 用户分配完退出等待池子
                        client_wait_pool.remove(u)
                    # 用户请求量更新
                    client_query_bandwidth[user] -= server_now_bandwidth
                    # 边缘服务量更新
                    server_bandwidth[server_index] = 0
                    server_now_bandwidth = 0
                    # 边缘使用完退出等待池子
                    server_wait_pool.remove(server_index)
                    break
                else:
                    # 服务器待分配带宽更新
                    server_now_bandwidth -= query
                    # 用户记录队列保存
                    user_list_temp.update({user: query})


    server_used = set(server_wait_pool_max) - set(server_wait_pool)
    # 最大池子节点使用次数计数（对还留在最大队列里，且本次被使用过最大策略的节点计数）
    for server_index in server_used:
        server_total_use_num[server_index] += 1

    # 更新服务等待池
    server_wait_pool += list(set(server_set) - set(server_wait_pool_max))

    # 对最大池子的值进行更新（超过5次就扔出去，后面直接在均值里用）
    for server_index, server_num in zip(server_total_use_num.keys(), server_total_use_num.values()):
        if server_index in server_used:
        # if server_index in server_wait_pool_max:
            # 删去使用过的节点
            server_wait_pool_max.remove(server_index)
            # 如果某个节点不超过5%临界点, 循环到极值策略待分配节点池最后，否则直接从池子里退出
            if server_num < demand_limit:
                server_wait_pool_max.append(server_index)


    # 从用户角度迭代，满足用户未满足的需求
    for client in client_wait_pool:
        use_server_index_list = []
        for server in server_list[client]:
            if server in server_wait_pool:
                use_server_index_list.append(server)
                # use_server_index_list
        query = client_query_bandwidth[client]

        server_temp = use_server_index_list.copy()
        # 迭代满足需求
        while query != 0:
            # 计算均值策略可用各边缘节点使用率
            use_rate = {node: (int(apply[qos_keys[node]][0]) - server_bandwidth[node]) / int(apply[qos_keys[node]][0])
                        for node in use_server_index_list}
            # 按照最大使用率差值计算各节点富余分配量
            # deliver_dict = {node: int((max(use_rate.values()) - use_rate[node]) * int(apply[qos_keys[node]][0]))
            #                 for node in use_server_index_list}
            deliver_dict = {}
            for node in use_server_index_list:
                deliver_dict.update({node: max(server_max_avg[node], server_avg_list[node])})

            # 如果请求超过了当前动态分配的结果
            if query >= sum(deliver_dict.values()):
                res_query = query - sum(deliver_dict.values())
                # 平均分担当前待分配带宽
                mean_deliver = res_query // len(use_server_index_list)
                left_deliver = res_query % len(use_server_index_list)
                for node in use_server_index_list:
                    deliver_dict[node] += mean_deliver
            # 如果请求不超过当前动态分配的结果
            else:
                temp = sum(deliver_dict.values())
                for node in use_server_index_list:
                    deliver_dict[node] = int(query * (deliver_dict[node] / temp))
                left_deliver = query - sum(deliver_dict.values())
            # print(deliver_dict)
            # print(sum(deliver_dict.values()), query-sum(deliver_dict.values())-left_deliver)

            for use_server_index in use_server_index_list.copy():
                free = server_bandwidth[use_server_index]
                if left_deliver > 0:
                    need = deliver_dict[use_server_index] + left_deliver
                    left_deliver = 0
                else:
                    need = deliver_dict[use_server_index]
                # # 如果待分配带宽为0
                # if free == 0:
                #     continue
                # 如果分配请求超过该节点可提供带宽上限
                if need > free:
                    # 存储单个分配节点信息
                    single_res[client].append({use_server_index: free})
                    # 请求总量减小
                    query -= free
                    # 均值策略该节点待分配量归0
                    server_bandwidth[use_server_index] = 0
                    use_server_index_list.remove(use_server_index)
                else:
                    # 分配量为均值
                    single_res[client].append({use_server_index: need})
                    # 请求总量减小
                    query -= need
                    # 均值策略该节点待分配量减小
                    server_bandwidth[use_server_index] -= need
        # print(server_bandwidth)
        for index, value in zip(server_bandwidth.keys(), server_bandwidth.values()):
            if index in server_temp:
                server_max_avg[index] = max(server_max_avg[index], int(apply[qos_keys[index]][0]) - value)
        # # 该用户需求已分配完, 退出等待分配池
        # client_wait_pool.pop(0)


    def Calc_points():
        temp_res = {ii: 0 for ii in server_set}
        for key, value in zip(single_res.keys(), single_res.values()):
            for res in value:
                for index, num in zip(res.keys(), res.values()):
                    temp_res[index] += num
        # print(temp_res)
        for index, num in zip(temp_res.keys(), temp_res.values()):
            server_total_use_bandwidth[index].append(num)
        for index in server_total_use_bandwidth.keys():
            server_total_use_bandwidth[index] = sorted(server_total_use_bandwidth[index], reverse=True) if len(
                server_total_use_bandwidth[index]) else []


    # Calc_points()
    # if num < 10:
    #     print(server_total_use_bandwidth[97])
    final_res.append(single_res)

# print(server_total_use_bandwidth)

# 按照原先顺序调整
temp = final_res.copy()
for i, index in enumerate(demand_sequence):
    final_res[index] = temp[i]

output(final_res)

# end = time.time()
# print(end - start)
