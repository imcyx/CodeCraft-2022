import os
# import time
import numpy as np

# start = time.time()

# os.chdir("../../")
# directory = "./pressure_data"
# directory = "./data"
# save_directory = "./output"

directory = "/data"
save_directory = "/output"

demand_src = "demand.csv"
apply_src = "site_bandwidth.csv"
qos_src = "qos.csv"
config_src = "config.ini"

save_file = "solution.txt"
if not os.path.exists(save_directory):
    os.makedirs(save_directory)

def read_csv(path):
    self_ele, self_data = [], {}
    with open(path, "r", encoding='UTF-8') as f:
        reader = f.readlines()
        for i, row in enumerate(reader):
            row_ = row.strip("\n").split(",")
            if i == 0:
                self_ele = row_[1:]
            else:
                self_data.update({row_[0]: row_[1:]})
    return self_data, self_ele

def read_config(path):
    with open(path, "r") as f:
        res = f.readlines()[-1]
        return res.split('=')[-1]

demand, demand_user_id = read_csv(os.path.join(directory, demand_src))
apply, _  = read_csv(os.path.join(directory, apply_src))
qos, qos_user_id = read_csv(os.path.join(directory, qos_src))
qos_constraint = int(read_config(os.path.join(directory, config_src)))

demand_keys = np.array([item for item in demand.keys()], dtype=np.str)
demand = np.array([list(item) for item in demand.values()], dtype=np.int)
qos_keys = np.array([item for item in qos.keys()], dtype=np.str)
qos = np.array([list(item) for item in qos.values()], dtype=np.int)

# 挑选出满足每个客户带宽需求的边缘节点
def limit_bandwidth(axis_input):
    index_temp = np.where(qos[:, axis_input] < qos_constraint)
    qos_temp = np.array((index_temp[0], qos[index_temp][:, axis_input])).T
    qos_temp = qos_temp[np.argsort(qos_temp[:, 1], axis=0)]
    return qos_temp

# 每个用户满足的节点列表
qos_limit_res = []
# 每个用户满足的节点数量排序
qos_limit_rank = []
for i in range(len(demand[0])):
    qos_limit_res.append(limit_bandwidth(i))
    qos_limit_rank.append(len(limit_bandwidth(i)))
# 每个客户所有满足的边缘节点的列表
# 增加排序，（由于边缘节点时延目前无需考虑，直接按照序号排列），保证满足边缘节点搜索优先度
apply_list = [sorted(list(qos_limit_res[i][:, 0])) for i in range(len(qos_limit_rank))]
# 每个客户拥有满足的边缘节点的数量
# 根据满足边缘节点进行排序，按照每个客户节点可以满足个数升序排序
apply_rank = np.argsort(np.array(qos_limit_rank))
# 排除完全没有边缘可以满足的用户
while not len(apply_list[apply_rank[0]]):
    apply_rank = np.delete(apply_rank, 0)
# 所有客户可用的边缘节点集合
apply_set = []
# 构建所有可用边缘节点列表
for x in qos_limit_res:
    apply_set += list(x[:,0])
apply_set = set(apply_set)


def output(final_res):
    with open(os.path.join(save_directory, save_file), "w+") as f:
        for single_time_res in final_res:
            for single_user_name, single_user_value in zip(single_time_res.keys(), single_time_res.values()):
                f.write(f"{demand_user_id[single_user_name]}:")
                flag = 0
                for i, every_node_res in enumerate(single_user_value):
                    for every_node_name, every_node_value in zip(every_node_res.keys(), every_node_res.values()):
                        # print(every_node_name, every_node_value)
                        # 如果分配量为0,无需写入
                        if every_node_value == 0:
                            continue
                        else:
                            # 第一个分配前无需","
                            if not flag:
                                flag = 1
                            else:
                                f.write(",")
                            f.write(f"<{every_node_name},{every_node_value}>")
                f.write("\n")

# 前百分之5请求分界线(95%总请求次数向上取整)
demand_limit = len(demand) - np.ceil(len(demand) * 0.95)
# 最终结果
final_res = []
# 节点使用统计
total_apply_count = {s:0 for s in apply_set}
# 总计已经使用边缘节点集合
apply_index_pool_avg = []
# 等待分配边缘节点池(按平均分配策略)
apply_wait_pool_avg = {i:[] for i in range(len(list(apply_rank)))}
# 开始进行匹配
for num, query_bandwidth in enumerate(demand):
    # print(apply_list[0])
    # 等待分配用户节点池
    user_wait_pool = list(apply_rank)
    # 单次分配结果字典
    single_res = {i:[] for i in range(len(user_wait_pool))}
    # 已经使用边缘节点池
    already_use_apply_pool = {i:[] for i in range(len(user_wait_pool))}
    # 等待分配边缘节点池(按最大分配策略)
    apply_wait_pool_max = apply_list
    # apply_wait_pool_max = [[*sub_list] for sub_list in apply_list]   # 全局复制自apply_list
    # 此时已经使用边缘节点集合
    already_use_set = []
    # 全局边缘节点带宽大小
    apply_bandwidth = {node: int(apply[qos_keys[node]][0]) for node in apply_set}
    while len(user_wait_pool):
        user = user_wait_pool[0]
        # 处理入口
        def handler(query):
            # 如果最大策略等待分配边缘节点池还有可用节点
            if len(apply_wait_pool_max[user]):
                max_strategy(query)
            else:
                mean_strategy(query)
        # 最大策略
        def max_strategy(query):
            # 弹出当前用户边缘节点池顶端节点作为第一首选分配
            # use_node_index: 使用边缘节点索引
            use_node_index = apply_wait_pool_max[user].pop(0)
            # use_node_name: 使用边缘节点名称
            use_node_name = qos_keys[use_node_index]
            # use_node_bandwidth: 使用边缘节点带宽
            use_node_bandwidth = apply_bandwidth[use_node_index]
            # 加入已使用边缘节点池
            already_use_apply_pool[user].append(use_node_index)
            # 如果请求 > 提供，单个边缘不能满足分配
            if query > use_node_bandwidth:
                # 如果还有用户也有这个边缘节点，删除，保证不再进行分配
                for x in user_wait_pool:
                    if use_node_index in apply_wait_pool_max[x]:
                        apply_wait_pool_max[x].remove(use_node_index)
                        # 加入已使用边缘节点池
                        already_use_apply_pool[x].append(use_node_index)
                # 存储单个分配节点信息
                single_res[user].append({use_node_name: use_node_bandwidth})
                apply_bandwidth[use_node_index] = 0
                # 递归边缘节点池,寻找下一个可用边缘节点
                handler(query - use_node_bandwidth)
            # 如果请求 < 提供，能满足
            else:
                # 存储当前用户分配节点信息
                single_res[user].append({use_node_name: query})
                apply_bandwidth[use_node_index] -= query
                # 该用户需求已分配完, 退出等待分配池
                user_wait_pool.pop(0)
                # 下面开始尝试分配该边缘节点剩余带宽给其它用户
                # 当前边缘节点剩余可分配带宽
                free = use_node_bandwidth - query
                # 遍历剩下的用户节点
                for x in user_wait_pool.copy():
                    # 如果还有用户也有这个边缘节点，给它分配
                    if use_node_index in apply_wait_pool_max[x]:
                        # 保证该用户不再请求这个节点
                        apply_wait_pool_max[x].remove(use_node_index)
                        # 加入已使用边缘节点池
                        already_use_apply_pool[x].append(use_node_index)
                        # 需求带宽大小
                        query = query_bandwidth[x]
                        # 如果已经没有可分配带宽,则直接从该用户边缘节点池删除然后找下一个用户
                        if free == 0:
                            continue
                        # 如果分配不能完全，提供可提供部分
                        elif query >= free:
                            # 存储单个分配节点信息
                            single_res[x].append({use_node_name: free})
                            apply_bandwidth[use_node_index] = 0
                            # 更新分配数量
                            query_bandwidth[x] -= free
                            free = 0
                        # 如果分配能够完全，分配该用户然后从等待列表里退出
                        else:
                            # 存储单个分配节点信息
                            single_res[x].append({use_node_name: query})
                            apply_bandwidth[use_node_index] -= query
                            # 更新分配数量
                            free -= query_bandwidth[x]
                            query_bandwidth[x] = 0
                            # 该用户需求已分配完, 退出等待分配池
                            user_wait_pool.remove(x)

        def mean_strategy(query):
            # 当前用户使用均值分配的边缘节点列表
            use_node_index_list = apply_wait_pool_avg[user].copy()

            while query != 0:
                # 平均分担当前待分配带宽
                mean_deliver = query // len(use_node_index_list)
                left_deliver = query % len(use_node_index_list)

                # use_node_index = use_node_index_list[-1]
                # use_node_name = qos_keys[use_node_index]
                # use_node_bandwidth = int(apply[use_node_name][0])
                # # 存储单个分配节点信息(不能整除部分的分配)
                # single_res[user].append({use_node_name: query - mean_deliver * (len(use_node_index_list)-1)})

                for use_node_index in use_node_index_list.copy():
                    use_node_name = qos_keys[use_node_index]
                    free = apply_bandwidth[use_node_index]
                    if left_deliver > 0:
                        need = mean_deliver + left_deliver
                        left_deliver = 0
                    else:
                        need = mean_deliver
                    # # 如果待分配带宽为0
                    # if free == 0:
                    #     continue
                    # 如果分配请求超过该节点可提供带宽上限
                    if need > free:
                        # 存储单个分配节点信息
                        single_res[user].append({use_node_name: free})
                        # 请求总量减小
                        query -= free
                        # 均值策略该节点待分配量归0
                        apply_bandwidth[use_node_index] = 0
                        use_node_index_list.remove(use_node_index)
                    else:
                        # 分配量为均值
                        single_res[user].append({use_node_name: need})
                        # 请求总量减小
                        query -= need
                        # 均值策略该节点待分配量减小
                        apply_bandwidth[use_node_index] -= need
            # 该用户需求已分配完, 退出等待分配池
            user_wait_pool.pop(0)

        handler(query_bandwidth[user])

    # 对使用过的节点数量计数
    for value in already_use_apply_pool.values():
        already_use_set = list(set(already_use_set + value))
    for index in already_use_set:
        total_apply_count[index] += 1

    # 动态调整边缘节点池
    for key, value in zip(already_use_apply_pool.keys(), already_use_apply_pool.values()):
        for index in sorted(value):
            # 如果某个节点不超过5%临界点, 循环到极值策略待分配节点池最后
            if total_apply_count[index] <= demand_limit:
                apply_wait_pool_max[key].append(index)
            # 否则丢入均值策略待分配节点池
            elif index not in apply_wait_pool_avg[key]:
                apply_wait_pool_avg[key].append(index)
        apply_index_pool_avg += apply_wait_pool_avg[key]
    # 目前已经存在于均值策略边缘节点池的节点
    apply_index_pool_avg = list(set(apply_index_pool_avg))

    final_res.append(single_res)
    # print(single_res)
    # print(apply_index_pool_avg)
    print(apply_wait_pool_avg)

output(final_res)

# end = time.time()
# print(end - start)
