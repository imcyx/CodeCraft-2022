import os
os.chdir("../../")
# import time
import numpy as np

# start = time.time()
directory = "./data"
demand_src = "demand.csv"
apply_src = "site_bandwidth.csv"
qos_src = "qos.csv"
config_src = "config.ini"

save_directory = "./output"
save_file = "solution.txt"
if not os.path.exists(save_directory):
    os.makedirs(save_directory)

def read_csv(path):
    self_ele, self_data = [], {}
    with open(path, "r", encoding='UTF-8') as f:
        reader = f.readlines()
        for i, row in enumerate(reader):
            row_ = row.strip("\n").split(",")
            if i == 0:
                self_ele = row_[1:]
            else:
                self_data.update({row_[0]: row_[1:]})
    return self_data, self_ele

def read_config(path):
    with open(path, "r") as f:
        res = f.readlines()[-1]
        return res.split('=')[-1]

demand, demand_user_id = read_csv(os.path.join(directory, demand_src))
apply, _  = read_csv(os.path.join(directory, apply_src))
qos, qos_user_id = read_csv(os.path.join(directory, qos_src))
qos_constraint = int(read_config(os.path.join(directory, config_src)))

demand2 = np.array([list(item) for item in demand.values()], dtype=np.int)
demand2_keys = np.array([item for item in demand.keys()], dtype=np.str)
qos2 = np.array([list(item) for item in qos.values()], dtype=np.int)
qos2_keys = np.array([item for item in qos.keys()], dtype=np.str)
# apply2 = np.array([item for item in apply.values()], dtype=np.int)
# apply2_keys = np.array([item for item in apply.keys()], dtype=np.str)

# 挑选出满足每个客户带宽需求的边缘节点
def limit_bandwidth(axis_input):
    index_temp = np.where(qos2[:, axis_input] < qos_constraint)
    qos_temp = np.array((index_temp[0], qos2[index_temp][:, axis_input])).T
    qos_temp = qos_temp[np.argsort(qos_temp[:, 1], axis=0)]
    return qos_temp

qos_limit_res = []
qos_limit_rank = []
for i in range(len(demand2[0])):
    qos_limit_res.append(limit_bandwidth(i))
    qos_limit_rank.append(len(limit_bandwidth(i)))
# 每个客户所有满足的边缘节点的列表
# 增加排序，（由于边缘节点时延目前无需考虑，直接按照序号排列），保证满足边缘节点搜索优先度
qos_all_enable = [sorted(list(qos_limit_res[i][:, 0])) for i in range(len(demand2[0]))]
# 根据满足边缘节点进行排序，按照每个客户节点可以满足个数升序排序
query_rank = np.argsort(np.array(qos_limit_rank))
for i in query_rank:
    print(len(qos_all_enable[i]), qos_all_enable[i])

def output(final_res):
    with open(os.path.join(save_directory, save_file), "w+") as f:
        for single_time_res in final_res:
            for single_user_res in single_time_res:
                # print(sorted(res.items(), key=lambda item: item[1]))
                for single_user_name, single_user_value in zip(single_user_res.keys(), single_user_res.values()):
                    f.write(f"{demand_user_id[single_user_name]}:")
                    for i, every_node_res in enumerate(single_user_value):
                        for every_node_name, every_node_value in zip(every_node_res.keys(), every_node_res.values()):
                            if i > 0:
                                f.write(",")
                            if every_node_value == 0:
                                continue
                            else:
                                f.write(f"<{every_node_name},{every_node_value}>")
                    f.write(os.linesep)


final_res = []
# 开始进行匹配
for query_bandwidth in demand2:
    single_time_use_node_set, single_time_use_node_details = [], []
    for num, i in enumerate(query_rank):
        use_node, use_node_details = [], []
        def handler(query):
            # 考虑递归检查，使得每次某个客户节点分配的边缘节点不被其它客户共享
            def gloabl_deliver_check():
                # 弹出队列最上的边缘节点作为第一首选分配
                apply_node_number = qos_all_enable[i].pop(0)
                # 将此次取出的节点重新放入队列末尾
                qos_all_enable[i].append(apply_node_number)
                # 加入当前使用边缘节点列表
                use_node.append(apply_node_number)
                # 如果取出的边缘节点已经在本轮被其它客户节点分配
                if len(set(single_time_use_node_set + use_node)) != num + 1:
                    # 当前使用边缘节点列表里退出该节点，并重新检索
                    use_node.pop()
                    return gloabl_deliver_check()
                else:
                    # 返回当前分配节点名称
                    name = qos2_keys[apply_node_number]
                    return name
            apply_node_name = gloabl_deliver_check()
            # 如果待分配带宽超过目前栈顶边缘节点能够提供的带宽
            if query > int(apply[apply_node_name][0]):
                # 存储单个分配节点信息
                use_node_details.append({apply_node_name: int(apply[apply_node_name][0])})
                handler(query - int(apply[apply_node_name][0]))
            else:
                # 存储单个分配节点信息
                use_node_details.append({apply_node_name: query})
        handler(query_bandwidth[i])
        single_time_use_node_set += use_node
        # 存储单个时间序列最终的输出结果
        single_time_use_node_details.append({i: use_node_details})
    # print(single_time_use_node_details)
    final_res.append(single_time_use_node_details)

output(final_res)

# end = time.time()
# print(end - start)
